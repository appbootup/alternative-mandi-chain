
This is mobile app for Alternatuve Mandi


1. Run the command
	npm install
	ionic serve



Description of what app does
---------------------------------
This app demonstrates, use of ionic2 based apps with

1. mongodb to store data
2. use of node.js as blockchain server to interact with mongodb and blockchain
3. use of angular.js to take data from browser and insert into mongodb.
4. integration of mongodb, node.js, angular.js, multichain blockchain


	
	
